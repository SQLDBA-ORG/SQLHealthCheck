using SqlCheckLibrary.Models;
using SqlCheckLibrary.Services;

namespace SqlCheckDemo
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== SQL Server Health Check Demo ===\n");

            // Your connection string here
            var connectionString = "Server=localhost;Database=master;Integrated Security=true;TrustServerCertificate=true;";
            
            if (args.Length > 0)
            {
                connectionString = args[0];
            }

            try
            {
                // Load checks from JSON
                var repository = new CheckRepository();
                await repository.LoadChecksAsync();
                
                var checks = repository.GetEnabledChecks();
                Console.WriteLine($"Loaded {checks.Count} checks from sql-checks.json\n");

                // Test connection
                var runner = new CheckRunner(connectionString);
                Console.WriteLine("Testing connection...");
                
                if (!await runner.TestConnectionAsync())
                {
                    Console.WriteLine("❌ Could not connect to SQL Server");
                    Console.WriteLine("Update connection string in code or pass as argument");
                    return;
                }
                
                Console.WriteLine("✅ Connected successfully\n");

                // Run all checks
                Console.WriteLine("Running checks...\n");
                var results = await runner.RunChecksAsync(checks);

                // Display results grouped by category
                var categories = results.GroupBy(r => r.Category).OrderBy(g => g.Key);

                foreach (var category in categories)
                {
                    Console.WriteLine($"[{category.Key}]");
                    Console.WriteLine(new string('-', 60));

                    foreach (var result in category)
                    {
                        var icon = result.Passed ? "✅" : "❌";
                        var severity = result.Passed ? "" : $"[{result.Severity}]";
                        
                        Console.WriteLine($"{icon} {result.CheckName} {severity}");
                        
                        if (!result.Passed)
                        {
                            Console.WriteLine($"   {result.Message}");
                            if (!string.IsNullOrEmpty(result.ErrorMessage))
                            {
                                Console.WriteLine($"   Error: {result.ErrorMessage}");
                            }
                        }
                    }
                    Console.WriteLine();
                }

                // Summary
                var passed = results.Count(r => r.Passed);
                var failed = results.Count(r => !r.Passed);
                var critical = results.Count(r => !r.Passed && r.Severity == "Critical");
                
                Console.WriteLine("=== Summary ===");
                Console.WriteLine($"Total Checks: {results.Count}");
                Console.WriteLine($"Passed: {passed}");
                Console.WriteLine($"Failed: {failed}");
                if (critical > 0)
                {
                    Console.WriteLine($"⚠️  Critical Issues: {critical}");
                }
                
                Console.WriteLine("\n💡 Tip: Edit sql-checks.json to add/modify/disable checks");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
            }
        }
    }
}
