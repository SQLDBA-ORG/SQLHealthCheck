using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Data.SqlClient;

namespace SqlMonitorUI
{
    public partial class LiveMonitoringWindow : Window
    {
        private readonly string _connectionString;
        private DispatcherTimer? _refreshTimer;
        private bool _isRunning = false;
        private long _lastBatchReq = 0;
        private long _lastTrans = 0;
        private long _lastComp = 0;
        private DateTime _lastSampleTime = DateTime.MinValue;

        public LiveMonitoringWindow(string connectionString)
        {
            InitializeComponent();
            _connectionString = connectionString;
            
            // Get server name
            try
            {
                var builder = new SqlConnectionStringBuilder(connectionString);
                ServerNameText.Text = builder.DataSource;
            }
            catch
            {
                ServerNameText.Text = "Unknown server";
            }
        }

        private void StartStopButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isRunning)
                StopMonitoring();
            else
                StartMonitoring();
        }

        private void StartMonitoring()
        {
            _isRunning = true;
            StartStopButton.Content = "⏹ Stop";
            StartStopButton.Background = new SolidColorBrush(Color.FromRgb(216, 59, 1));
            
            var interval = GetRefreshInterval();
            _refreshTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(interval) };
            _refreshTimer.Tick += async (s, e) => await RefreshDataAsync();
            _refreshTimer.Start();
            
            // Initial refresh
            _ = RefreshDataAsync();
            StatusText.Text = "Monitoring...";
        }

        private void StopMonitoring()
        {
            _isRunning = false;
            StartStopButton.Content = "▶ Start";
            StartStopButton.Background = new SolidColorBrush(Color.FromRgb(16, 124, 16));
            
            _refreshTimer?.Stop();
            _refreshTimer = null;
            StatusText.Text = "Stopped";
        }

        private int GetRefreshInterval()
        {
            return RefreshIntervalCombo.SelectedIndex switch
            {
                0 => 1,
                1 => 5,
                2 => 10,
                3 => 30,
                _ => 5
            };
        }

        private void RefreshIntervalCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isRunning && _refreshTimer != null)
            {
                _refreshTimer.Interval = TimeSpan.FromSeconds(GetRefreshInterval());
            }
        }

        private async System.Threading.Tasks.Task RefreshDataAsync()
        {
            try
            {
                await System.Threading.Tasks.Task.Run(() =>
                {
                    using var connection = new SqlConnection(_connectionString);
                    connection.Open();
                    
                    // Get performance metrics
                    var metricsData = GetPerformanceMetrics(connection);
                    
                    // Get sessions
                    var sessionsData = GetActiveSessions(connection);
                    
                    // Update UI on dispatcher thread
                    Dispatcher.Invoke(() =>
                    {
                        UpdateMetricsDisplay(metricsData);
                        UpdateSessionsDisplay(sessionsData);
                        LastUpdateText.Text = $"Last update: {DateTime.Now:HH:mm:ss}";
                    });
                });
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() =>
                {
                    StatusText.Text = $"Error: {ex.Message}";
                    StatusText.Foreground = new SolidColorBrush(Colors.Red);
                });
            }
        }

        private DataTable GetPerformanceMetrics(SqlConnection connection)
        {
            const string query = @"
                DECLARE @LgReads BIGINT
                SELECT @LgReads = cntr_value FROM sys.dm_os_performance_counters WHERE counter_name = 'Page lookups/sec'

                DECLARE @BatchReq BIGINT
                SELECT @BatchReq = ISNULL(SUM(CONVERT(BIGINT, cntr_value)), 0) 
                FROM sys.dm_os_performance_counters 
                WHERE LOWER(object_name) LIKE '%sql statistics%' AND LOWER(counter_name) = 'batch requests/sec'

                DECLARE @SqlComp BIGINT
                SELECT @SqlComp = ISNULL(SUM(CONVERT(BIGINT, cntr_value)), 0) 
                FROM sys.dm_os_performance_counters 
                WHERE LOWER(object_name) LIKE '%sql statistics%' AND LOWER(counter_name) = 'sql compilations/sec'

                DECLARE @SqlRecomp BIGINT
                SELECT @SqlRecomp = ISNULL(SUM(CONVERT(BIGINT, cntr_value)), 0) 
                FROM sys.dm_os_performance_counters 
                WHERE LOWER(object_name) LIKE '%sql statistics%' AND LOWER(counter_name) = 'sql re-compilations/sec'

                DECLARE @Trans BIGINT
                SELECT @Trans = ISNULL(SUM(CONVERT(BIGINT, cntr_value)), 0) 
                FROM sys.dm_os_performance_counters 
                WHERE LOWER(object_name) LIKE '%databases%' AND LOWER(counter_name) = 'transactions/sec' AND LOWER(instance_name) <> '_total'

                DECLARE @cpu INT
                SELECT TOP 1 @cpu = CONVERT(XML, record).value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int')
                FROM sys.dm_os_ring_buffers
                WHERE ring_buffer_type = 'RING_BUFFER_SCHEDULER_MONITOR'
                ORDER BY timestamp DESC

                SELECT 
                    ISNULL(@cpu, 0) AS CPU,
                    SUM(CONVERT(BIGINT, CASE WHEN wait_type LIKE 'LCK%' THEN wait_time_ms - signal_wait_time_ms ELSE 0 END)) AS Locks,
                    SUM(CONVERT(BIGINT, CASE WHEN wait_type LIKE 'LATCH%' OR wait_type LIKE 'PAGELATCH%' OR wait_type LIKE 'PAGEIOLATCH%' THEN wait_time_ms - signal_wait_time_ms ELSE 0 END)) AS Reads,
                    SUM(CONVERT(BIGINT, CASE WHEN wait_type LIKE '%IO_COMPLETION%' OR wait_type = 'WRITELOG' THEN wait_time_ms - signal_wait_time_ms ELSE 0 END)) AS Writes,
                    SUM(CONVERT(BIGINT, CASE WHEN wait_type IN ('NETWORKIO', 'OLEDB', 'ASYNC_NETWORK_IO') THEN wait_time_ms - signal_wait_time_ms ELSE 0 END)) AS Network,
                    SUM(CONVERT(BIGINT, CASE WHEN wait_type LIKE 'BACKUP%' OR wait_type = 'DISKIO_SUSPEND' THEN wait_time_ms - signal_wait_time_ms ELSE 0 END)) AS [Backup],
                    SUM(CONVERT(BIGINT, CASE WHEN wait_type = 'CMEMTHREAD' OR wait_type LIKE 'RESOURCE_SEMAPHORE%' THEN wait_time_ms - signal_wait_time_ms ELSE 0 END)) AS Memory,
                    SUM(CONVERT(BIGINT, CASE WHEN wait_type = 'CXPACKET' OR wait_type = 'EXCHANGE' THEN wait_time_ms - signal_wait_time_ms ELSE 0 END)) AS Parallelism,
                    SUM(CONVERT(BIGINT, CASE WHEN wait_type = 'LOGBUFFER' OR wait_type = 'LOGMGR' OR wait_type = 'WRITELOG' THEN wait_time_ms - signal_wait_time_ms ELSE 0 END)) AS TransactionLog,
                    @@TOTAL_READ AS PhReads, 
                    @@TOTAL_WRITE AS PhWrites, 
                    ISNULL(@LgReads, 0) AS LgReads,
                    @BatchReq AS BatchReq, 
                    @SqlComp AS SqlComp, 
                    @SqlRecomp AS SqlRecomp, 
                    @Trans AS Trans
                FROM sys.dm_os_wait_stats";

            using var command = new SqlCommand(query, connection) { CommandTimeout = 30 };
            using var adapter = new SqlDataAdapter(command);
            var dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }

        private DataTable GetActiveSessions(SqlConnection connection)
        {
            const string query = @"
                SELECT 
                    p.spid AS Spid,
                    DB_NAME(p.dbid) AS [Database],
                    p.status AS Status,
                    CAST(p.cpu / 1000 AS BIGINT) AS Cpu,
                    CAST(p.physical_io AS BIGINT) AS PhysicalIo,
                    p.hostname AS Hostname,
                    p.program_name AS ProgramName,
                    p.loginame AS LoginName,
                    p.blocked AS Blocked,
                    p.waittime AS WaitTime,
                    p.lastwaittype AS LastWaitType
                FROM sys.sysprocesses p
                WHERE p.spid > 50 
                    AND p.status <> 'sleeping'
                    AND p.program_name NOT LIKE '%SQLMonitorUI%'
                ORDER BY p.cpu DESC";

            using var command = new SqlCommand(query, connection) { CommandTimeout = 30 };
            using var adapter = new SqlDataAdapter(command);
            var dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }

        private void UpdateMetricsDisplay(DataTable dt)
        {
            if (dt.Rows.Count == 0) return;
            var row = dt.Rows[0];

            // CPU
            var cpu = Convert.ToInt32(row["CPU"]);
            CpuText.Text = cpu.ToString();
            CpuText.Foreground = new SolidColorBrush(cpu > 80 ? Color.FromRgb(216, 59, 1) : Color.FromRgb(0, 120, 212));

            // Calculate per-second rates
            var now = DateTime.Now;
            var batchReq = Convert.ToInt64(row["BatchReq"]);
            var trans = Convert.ToInt64(row["Trans"]);
            var comp = Convert.ToInt64(row["SqlComp"]);

            if (_lastSampleTime != DateTime.MinValue)
            {
                var elapsed = (now - _lastSampleTime).TotalSeconds;
                if (elapsed > 0)
                {
                    BatchReqText.Text = ((batchReq - _lastBatchReq) / elapsed).ToString("N0");
                    TransText.Text = ((trans - _lastTrans) / elapsed).ToString("N0");
                    CompilationsText.Text = ((comp - _lastComp) / elapsed).ToString("N0");
                }
            }

            _lastBatchReq = batchReq;
            _lastTrans = trans;
            _lastComp = comp;
            _lastSampleTime = now;

            // Physical I/O
            ReadsText.Text = Convert.ToInt64(row["PhReads"]).ToString("N0");
            WritesText.Text = Convert.ToInt64(row["PhWrites"]).ToString("N0");

            // Wait stats
            var waitStats = new List<WaitStatItem>
            {
                new WaitStatItem { WaitType = "Locks", WaitTimeMs = Convert.ToInt64(row["Locks"]) },
                new WaitStatItem { WaitType = "Reads/Latches", WaitTimeMs = Convert.ToInt64(row["Reads"]) },
                new WaitStatItem { WaitType = "Writes/I/O", WaitTimeMs = Convert.ToInt64(row["Writes"]) },
                new WaitStatItem { WaitType = "Network", WaitTimeMs = Convert.ToInt64(row["Network"]) },
                new WaitStatItem { WaitType = "Backup", WaitTimeMs = Convert.ToInt64(row["Backup"]) },
                new WaitStatItem { WaitType = "Memory", WaitTimeMs = Convert.ToInt64(row["Memory"]) },
                new WaitStatItem { WaitType = "Parallelism", WaitTimeMs = Convert.ToInt64(row["Parallelism"]) },
                new WaitStatItem { WaitType = "Transaction Log", WaitTimeMs = Convert.ToInt64(row["TransactionLog"]) }
            };

            var totalWait = waitStats.Sum(w => w.WaitTimeMs);
            if (totalWait > 0)
            {
                foreach (var w in waitStats)
                    w.Percentage = (double)w.WaitTimeMs / totalWait * 100;
            }

            WaitStatsGrid.ItemsSource = waitStats.Where(w => w.WaitTimeMs > 0).OrderByDescending(w => w.WaitTimeMs).ToList();
        }

        private void UpdateSessionsDisplay(DataTable dt)
        {
            var sessions = new List<SessionItem>();
            foreach (DataRow row in dt.Rows)
            {
                sessions.Add(new SessionItem
                {
                    Spid = Convert.ToInt32(row["Spid"]),
                    Database = row["Database"]?.ToString() ?? "",
                    Status = row["Status"]?.ToString() ?? "",
                    Cpu = Convert.ToInt64(row["Cpu"]),
                    PhysicalIo = Convert.ToInt64(row["PhysicalIo"]),
                    Hostname = row["Hostname"]?.ToString() ?? "",
                    ProgramName = row["ProgramName"]?.ToString() ?? ""
                });
            }

            SessionsGrid.ItemsSource = sessions;
            SessionCountText.Text = $" ({sessions.Count})";
        }

        protected override void OnClosed(EventArgs e)
        {
            StopMonitoring();
            base.OnClosed(e);
        }
    }

    public class WaitStatItem
    {
        public string WaitType { get; set; } = "";
        public long WaitTimeMs { get; set; }
        public double Percentage { get; set; }
    }

    public class SessionItem
    {
        public int Spid { get; set; }
        public string Database { get; set; } = "";
        public string Status { get; set; } = "";
        public long Cpu { get; set; }
        public long PhysicalIo { get; set; }
        public string Hostname { get; set; } = "";
        public string ProgramName { get; set; } = "";
    }
}
