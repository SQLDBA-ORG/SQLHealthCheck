using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Data.SqlClient;

namespace SqlMonitorUI
{
    public partial class LiveMonitoringWindow : Window
    {
        private readonly string _connectionString;
        private DispatcherTimer? _refreshTimer;
        private bool _isRunning;
        private long _lastBatchReq, _lastTrans, _lastComp;
        private DateTime _lastSampleTime = DateTime.MinValue;

        private const int MaxHistoryPoints = 120;
        private readonly Dictionary<string, Queue<double>> _waitHistory = new();
        private readonly Dictionary<string, Color> _waitColors = new()
        {
            { "Locks", Color.FromRgb(220, 20, 60) }, { "Reads/Latches", Color.FromRgb(0, 120, 212) },
            { "Writes/I/O", Color.FromRgb(139, 0, 139) }, { "Network", Color.FromRgb(255, 140, 0) },
            { "Backup", Color.FromRgb(128, 128, 128) }, { "Memory", Color.FromRgb(16, 124, 16) },
            { "Parallelism", Color.FromRgb(107, 105, 214) }, { "Transaction Log", Color.FromRgb(216, 59, 1) }
        };

        // Baseline wait stats for delta calculation
        private Dictionary<string, long>? _baselineWaits;
        private Dictionary<string, long> _lastWaits = new();

        private readonly Dictionary<int, SpidHistory> _spidHistories = new();
        private const int SparklinePoints = 30;

        public LiveMonitoringWindow(string connectionString)
        {
            InitializeComponent();
            _connectionString = connectionString;
            foreach (var key in _waitColors.Keys) _waitHistory[key] = new Queue<double>();
            BuildLegend();
            try { ServerNameText.Text = new SqlConnectionStringBuilder(connectionString).DataSource; } catch { ServerNameText.Text = "Unknown"; }
            
            // Auto-start when window loads
            Loaded += (s, e) => StartMonitoring();
        }

        private void BuildLegend()
        {
            LegendPanel.Children.Clear();
            foreach (var kvp in _waitColors)
            {
                var sp = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 15, 5) };
                sp.Children.Add(new Rectangle { Width = 14, Height = 14, Fill = new SolidColorBrush(kvp.Value), Margin = new Thickness(0, 0, 5, 0), RadiusX = 2, RadiusY = 2 });
                sp.Children.Add(new TextBlock { Text = kvp.Key, FontSize = 11, VerticalAlignment = VerticalAlignment.Center });
                LegendPanel.Children.Add(sp);
            }
        }

        private void StartStopButton_Click(object sender, RoutedEventArgs e) { if (_isRunning) StopMonitoring(); else StartMonitoring(); }

        private void StartMonitoring()
        {
            _isRunning = true;
            _baselineWaits = null; // Reset baseline on start
            _lastWaits.Clear();
            StartStopButton.Content = "Stop";
            StartStopButton.Background = new SolidColorBrush(Color.FromRgb(216, 59, 1));
            _refreshTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(GetRefreshInterval()) };
            _refreshTimer.Tick += async (s, e) => await RefreshDataAsync();
            _refreshTimer.Start();
            _ = RefreshDataAsync();
            StatusText.Text = "Monitoring...";
        }

        private void StopMonitoring()
        {
            _isRunning = false;
            StartStopButton.Content = "Start";
            StartStopButton.Background = new SolidColorBrush(Color.FromRgb(16, 124, 16));
            _refreshTimer?.Stop(); _refreshTimer = null;
            StatusText.Text = "Stopped";
        }

        private int GetRefreshInterval() => RefreshIntervalCombo.SelectedIndex switch { 0 => 1, 1 => 5, 2 => 10, 3 => 30, _ => 5 };
        
        private void RefreshIntervalCombo_SelectionChanged(object sender, SelectionChangedEventArgs e) 
        { 
            if (_refreshTimer != null) 
                _refreshTimer.Interval = TimeSpan.FromSeconds(GetRefreshInterval()); 
        }

        private async System.Threading.Tasks.Task RefreshDataAsync()
        {
            try
            {
                await System.Threading.Tasks.Task.Run(() =>
                {
                    using var conn = new SqlConnection(_connectionString);
                    conn.Open();
                    var metrics = GetMetrics(conn);
                    var sessions = GetSessions(conn);
                    Dispatcher.Invoke(() => { UpdateMetrics(metrics); UpdateSessions(sessions); DrawWaitGraph(); UpdateSpidBoxes(); LastUpdateText.Text = $"Updated: {DateTime.Now:HH:mm:ss}"; });
                });
            }
            catch (Exception ex) { Dispatcher.Invoke(() => { StatusText.Text = $"Error: {ex.Message}"; }); }
        }

        private DataTable GetMetrics(SqlConnection conn)
        {
            const string q = @"DECLARE @BR BIGINT, @SC BIGINT, @TR BIGINT, @cpu INT
SELECT @BR=ISNULL(SUM(CONVERT(BIGINT,cntr_value)),0) FROM sys.dm_os_performance_counters WHERE LOWER(object_name) LIKE '%sql statistics%' AND LOWER(counter_name)='batch requests/sec'
SELECT @SC=ISNULL(SUM(CONVERT(BIGINT,cntr_value)),0) FROM sys.dm_os_performance_counters WHERE LOWER(object_name) LIKE '%sql statistics%' AND LOWER(counter_name)='sql compilations/sec'
SELECT @TR=ISNULL(SUM(CONVERT(BIGINT,cntr_value)),0) FROM sys.dm_os_performance_counters WHERE LOWER(object_name) LIKE '%databases%' AND LOWER(counter_name)='transactions/sec' AND LOWER(instance_name)<>'_total'
SELECT TOP 1 @cpu=CONVERT(XML,record).value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]','int') FROM sys.dm_os_ring_buffers WHERE ring_buffer_type='RING_BUFFER_SCHEDULER_MONITOR' ORDER BY timestamp DESC
SELECT ISNULL(@cpu,0) AS CPU,
SUM(CONVERT(BIGINT,CASE WHEN wait_type LIKE 'LCK%' THEN wait_time_ms-signal_wait_time_ms ELSE 0 END)) AS Locks,
SUM(CONVERT(BIGINT,CASE WHEN wait_type LIKE 'LATCH%' OR wait_type LIKE 'PAGELATCH%' OR wait_type LIKE 'PAGEIOLATCH%' THEN wait_time_ms-signal_wait_time_ms ELSE 0 END)) AS Reads,
SUM(CONVERT(BIGINT,CASE WHEN wait_type LIKE '%IO_COMPLETION%' OR wait_type='WRITELOG' THEN wait_time_ms-signal_wait_time_ms ELSE 0 END)) AS Writes,
SUM(CONVERT(BIGINT,CASE WHEN wait_type IN('NETWORKIO','OLEDB','ASYNC_NETWORK_IO') THEN wait_time_ms-signal_wait_time_ms ELSE 0 END)) AS Network,
SUM(CONVERT(BIGINT,CASE WHEN wait_type LIKE 'BACKUP%' THEN wait_time_ms-signal_wait_time_ms ELSE 0 END)) AS [Backup],
SUM(CONVERT(BIGINT,CASE WHEN wait_type='CMEMTHREAD' OR wait_type LIKE 'RESOURCE_SEMAPHORE%' THEN wait_time_ms-signal_wait_time_ms ELSE 0 END)) AS Memory,
SUM(CONVERT(BIGINT,CASE WHEN wait_type IN('CXPACKET','EXCHANGE') THEN wait_time_ms-signal_wait_time_ms ELSE 0 END)) AS Parallelism,
SUM(CONVERT(BIGINT,CASE WHEN wait_type IN('LOGBUFFER','LOGMGR','WRITELOG') THEN wait_time_ms-signal_wait_time_ms ELSE 0 END)) AS TransactionLog,
@@TOTAL_READ AS PhReads,@@TOTAL_WRITE AS PhWrites,@BR AS BatchReq,@SC AS SqlComp,@TR AS Trans FROM sys.dm_os_wait_stats";
            using var cmd = new SqlCommand(q, conn) { CommandTimeout = 30 };
            var dt = new DataTable(); new SqlDataAdapter(cmd).Fill(dt); return dt;
        }

        private DataTable GetSessions(SqlConnection conn)
        {
            const string q = "SELECT spid AS Spid,DB_NAME(dbid) AS [Database],status AS Status,CAST(cpu AS BIGINT) AS Cpu,CAST(physical_io AS BIGINT) AS PhysicalIo,hostname AS Hostname,program_name AS ProgramName FROM sys.sysprocesses WHERE spid>50 AND program_name NOT LIKE '%SQLMonitorUI%' ORDER BY cpu DESC";
            using var cmd = new SqlCommand(q, conn) { CommandTimeout = 30 };
            var dt = new DataTable(); new SqlDataAdapter(cmd).Fill(dt); return dt;
        }

        private void UpdateMetrics(DataTable dt)
        {
            if (dt.Rows.Count == 0) return;
            var r = dt.Rows[0];
            var cpu = Convert.ToInt32(r["CPU"]);
            CpuText.Text = cpu.ToString();
            CpuText.Foreground = new SolidColorBrush(cpu > 80 ? Color.FromRgb(216,59,1) : Color.FromRgb(0,120,212));

            var now = DateTime.Now;
            var br = Convert.ToInt64(r["BatchReq"]); var tr = Convert.ToInt64(r["Trans"]); var sc = Convert.ToInt64(r["SqlComp"]);
            if (_lastSampleTime != DateTime.MinValue)
            {
                var el = (now - _lastSampleTime).TotalSeconds;
                if (el > 0) { BatchReqText.Text = ((br-_lastBatchReq)/el).ToString("N0"); TransText.Text = ((tr-_lastTrans)/el).ToString("N0"); CompilationsText.Text = ((sc-_lastComp)/el).ToString("N0"); }
            }
            _lastBatchReq = br; _lastTrans = tr; _lastComp = sc; _lastSampleTime = now;
            ReadsText.Text = Convert.ToInt64(r["PhReads"]).ToString("N0");
            WritesText.Text = Convert.ToInt64(r["PhWrites"]).ToString("N0");

            // Current absolute wait values
            var currentWaits = new Dictionary<string,long>{
                {"Locks",Convert.ToInt64(r["Locks"])},
                {"Reads/Latches",Convert.ToInt64(r["Reads"])},
                {"Writes/I/O",Convert.ToInt64(r["Writes"])},
                {"Network",Convert.ToInt64(r["Network"])},
                {"Backup",Convert.ToInt64(r["Backup"])},
                {"Memory",Convert.ToInt64(r["Memory"])},
                {"Parallelism",Convert.ToInt64(r["Parallelism"])},
                {"Transaction Log",Convert.ToInt64(r["TransactionLog"])}
            };

            // Set baseline on first sample
            if (_baselineWaits == null)
            {
                _baselineWaits = new Dictionary<string, long>(currentWaits);
                _lastWaits = new Dictionary<string, long>(currentWaits);
            }

            // Calculate delta from last sample (for graph) and from baseline (for table)
            var deltaFromBaseline = new Dictionary<string, long>();
            var deltaFromLast = new Dictionary<string, long>();
            
            foreach (var key in currentWaits.Keys)
            {
                deltaFromBaseline[key] = currentWaits[key] - _baselineWaits[key];
                deltaFromLast[key] = currentWaits[key] - (_lastWaits.ContainsKey(key) ? _lastWaits[key] : currentWaits[key]);
            }
            
            _lastWaits = new Dictionary<string, long>(currentWaits);

            // Update table with delta from baseline
            var tot = deltaFromBaseline.Values.Sum();
            var ws = new List<WaitStatItem>();
            foreach (var kv in deltaFromBaseline)
            {
                var pct = tot > 0 ? (double)kv.Value/tot*100 : 0;
                ws.Add(new WaitStatItem{WaitType=kv.Key,WaitTimeMs=kv.Value,Percentage=pct,Color=new SolidColorBrush(_waitColors[kv.Key])});
            }
            WaitStatsGrid.ItemsSource = ws.Where(w=>w.WaitTimeMs>0).OrderByDescending(w=>w.WaitTimeMs).ToList();

            // Update graph with delta from last sample
            var totDelta = deltaFromLast.Values.Where(v => v > 0).Sum();
            foreach (var kv in deltaFromLast)
            {
                var pct = totDelta > 0 ? (double)Math.Max(0, kv.Value)/totDelta*100 : 0;
                _waitHistory[kv.Key].Enqueue(pct);
                while (_waitHistory[kv.Key].Count > MaxHistoryPoints) _waitHistory[kv.Key].Dequeue();
            }
        }

        private void DrawWaitGraph()
        {
            WaitGraphCanvas.Children.Clear();
            var w = WaitGraphCanvas.ActualWidth; var h = WaitGraphCanvas.ActualHeight;
            if (w <= 0 || h <= 0) return;
            var maxPts = _waitHistory.Values.Max(q => q.Count); if (maxPts < 2) return;
            var xStep = w / (MaxHistoryPoints - 1);
            var maxVal = _waitHistory.Values.SelectMany(q => q).DefaultIfEmpty(1).Max(); if (maxVal < 1) maxVal = 1;
            foreach (var kv in _waitHistory.Where(x => x.Value.Any(v => v > 0)))
            {
                var pts = kv.Value.ToArray(); var off = MaxHistoryPoints - pts.Length;
                var pl = new Polyline { Stroke = new SolidColorBrush(_waitColors[kv.Key]), StrokeThickness = 1.5 };
                for (int i = 0; i < pts.Length; i++) pl.Points.Add(new Point((off + i) * xStep, h - (pts[i] / maxVal * h * 0.9)));
                WaitGraphCanvas.Children.Add(pl);
            }
        }

        private void UpdateSessions(DataTable dt)
        {
            var sess = new List<SessionItem>(); long totCpu = 0, totIo = 0;
            foreach (DataRow r in dt.Rows)
            {
                var cpu = Convert.ToInt64(r["Cpu"]); var io = Convert.ToInt64(r["PhysicalIo"]);
                totCpu += cpu; totIo += io;
                sess.Add(new SessionItem{Spid=Convert.ToInt32(r["Spid"]),Database=r["Database"]?.ToString()??"",Status=r["Status"]?.ToString()??"",Cpu=cpu,PhysicalIo=io,Hostname=r["Hostname"]?.ToString()??"",ProgramName=r["ProgramName"]?.ToString()??""});
            }
            foreach (var s in sess)
            {
                var cpuPct = totCpu > 0 ? (double)s.Cpu/totCpu*100 : 0;
                var ioPct = totIo > 0 ? (double)s.PhysicalIo/totIo*100 : 0;
                if (!_spidHistories.ContainsKey(s.Spid)) _spidHistories[s.Spid] = new SpidHistory{Spid=s.Spid};
                _spidHistories[s.Spid].AddSample(cpuPct, ioPct);
                _spidHistories[s.Spid].Database = s.Database;
                _spidHistories[s.Spid].IsActive = true;
            }
            var active = sess.Select(x=>x.Spid).ToHashSet();
            foreach (var h in _spidHistories.Values) if (!active.Contains(h.Spid)) { h.IsActive = false; h.AddSample(0,0); }
            SessionsGrid.ItemsSource = sess;
            SessionCountText.Text = $" ({sess.Count})";
        }

        private void UpdateSpidBoxes()
        {
            SpidBoxesPanel.Children.Clear();
            var rel = _spidHistories.Values.Where(h=>h.CpuHistory.Any(v=>v>0)||h.IoHistory.Any(v=>v>0)).OrderByDescending(h=>h.IoHistory.Sum()).ThenByDescending(h=>h.CpuHistory.Sum());
            foreach (var sp in rel) SpidBoxesPanel.Children.Add(CreateSpidBox(sp));
        }

        private Border CreateSpidBox(SpidHistory sp)
        {
            var brd = new Border{MinWidth=100,MinHeight=60,Background=new SolidColorBrush(sp.IsActive?Color.FromRgb(250,250,250):Color.FromRgb(240,240,240)),BorderBrush=new SolidColorBrush(sp.IsActive?Color.FromRgb(0,120,212):Color.FromRgb(200,200,200)),BorderThickness=new Thickness(sp.IsActive?2:1),CornerRadius=new CornerRadius(4),Margin=new Thickness(5),Padding=new Thickness(8,5,8,5)};
            var g = new Grid();
            g.RowDefinitions.Add(new RowDefinition{Height=new GridLength(18)});
            g.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});
            g.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});
            var hdr = new TextBlock{Text=$"SPID {sp.Spid}"+(string.IsNullOrEmpty(sp.Database)?"":" ("+sp.Database+")"),FontSize=10,FontWeight=FontWeights.SemiBold,Foreground=new SolidColorBrush(sp.IsActive?Colors.Black:Colors.Gray),TextTrimming=TextTrimming.CharacterEllipsis};
            Grid.SetRow(hdr,0); g.Children.Add(hdr);
            var cpuC = new Canvas{Height=18,ClipToBounds=true}; Grid.SetRow(cpuC,1); g.Children.Add(cpuC);
            var ioC = new Canvas{Height=18,ClipToBounds=true}; Grid.SetRow(ioC,2); g.Children.Add(ioC);
            brd.Child = g;
            brd.Loaded += (s,e) => { DrawSparkline(cpuC,sp.CpuHistory.ToArray(),Color.FromRgb(0,120,212)); DrawSparkline(ioC,sp.IoHistory.ToArray(),Color.FromRgb(216,59,1)); };
            return brd;
        }

        private void DrawSparkline(Canvas c, double[] vals, Color col)
        {
            c.Children.Clear(); if (vals.Length < 2) return;
            var w = c.ActualWidth > 0 ? c.ActualWidth : 110; var h = c.ActualHeight > 0 ? c.ActualHeight : 18;
            var mx = vals.Max(); if (mx < 1) mx = 100;
            var xS = w / (SparklinePoints - 1); var off = SparklinePoints - vals.Length;
            var pl = new Polyline { Stroke = new SolidColorBrush(col), StrokeThickness = 1.5 };
            for (int i = 0; i < vals.Length; i++) pl.Points.Add(new Point((off + i) * xS, h - (vals[i] / mx * h * 0.85) - 1));
            c.Children.Add(pl);
        }

        protected override void OnClosed(EventArgs e) { StopMonitoring(); base.OnClosed(e); }
    }

    public class WaitStatItem { public string WaitType { get; set; } = ""; public long WaitTimeMs { get; set; } public double Percentage { get; set; } public SolidColorBrush Color { get; set; } = new SolidColorBrush(Colors.Gray); }
    public class SessionItem { public int Spid { get; set; } public string Database { get; set; } = ""; public string Status { get; set; } = ""; public long Cpu { get; set; } public long PhysicalIo { get; set; } public string Hostname { get; set; } = ""; public string ProgramName { get; set; } = ""; }
    public class SpidHistory { public int Spid { get; set; } public string Database { get; set; } = ""; public bool IsActive { get; set; } public Queue<double> CpuHistory { get; } = new(); public Queue<double> IoHistory { get; } = new(); public void AddSample(double c, double i) { CpuHistory.Enqueue(c); IoHistory.Enqueue(i); while (CpuHistory.Count > 30) CpuHistory.Dequeue(); while (IoHistory.Count > 30) IoHistory.Dequeue(); } }
}
