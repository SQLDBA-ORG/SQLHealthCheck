using System.Windows;

namespace SqlMonitorUI
{
    public partial class ImportChecksDialog : Window
    {
        public bool ImportSpBlitz { get; private set; }
        public bool ImportSpTriage { get; private set; }
        public string? SpBlitzPath { get; private set; }
        public string? SpTriagePath { get; private set; }

        public ImportChecksDialog()
        {
            InitializeComponent();
            UpdateImportButtonState();
        }

        private void BrowseSpBlitzButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Select sp_Blitz.sql file",
                Filter = "SQL Files (*.sql)|*.sql|All Files (*.*)|*.*",
                DefaultExt = ".sql"
            };

            if (dialog.ShowDialog() == true)
            {
                SpBlitzPathTextBox.Text = dialog.FileName;
                SpBlitzPath = dialog.FileName;
                SpBlitzCheckBox.IsChecked = true;
                UpdateImportButtonState();
            }
        }

        private void BrowseSpTriageButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Select sp_triage.sql file",
                Filter = "SQL Files (*.sql)|*.sql|All Files (*.*)|*.*",
                DefaultExt = ".sql"
            };

            if (dialog.ShowDialog() == true)
            {
                SpTriagePathTextBox.Text = dialog.FileName;
                SpTriagePath = dialog.FileName;
                SpTriageCheckBox.IsChecked = true;
                UpdateImportButtonState();
            }
        }

        private void SpBlitzCheckBox_Changed(object sender, RoutedEventArgs e)
        {
            BrowseSpBlitzButton.IsEnabled = SpBlitzCheckBox.IsChecked == true;
            UpdateImportButtonState();
        }

        private void SpTriageCheckBox_Changed(object sender, RoutedEventArgs e)
        {
            BrowseSpTriageButton.IsEnabled = SpTriageCheckBox.IsChecked == true;
            UpdateImportButtonState();
        }

        private void UpdateImportButtonState()
        {
            bool canImport = false;

            if (SpBlitzCheckBox.IsChecked == true && !string.IsNullOrEmpty(SpBlitzPath))
                canImport = true;

            if (SpTriageCheckBox.IsChecked == true && !string.IsNullOrEmpty(SpTriagePath))
                canImport = true;

            ImportButton.IsEnabled = canImport;
        }

        private void ImportButton_Click(object sender, RoutedEventArgs e)
        {
            ImportSpBlitz = SpBlitzCheckBox.IsChecked == true && !string.IsNullOrEmpty(SpBlitzPath);
            ImportSpTriage = SpTriageCheckBox.IsChecked == true && !string.IsNullOrEmpty(SpTriagePath);

            this.DialogResult = true;
            this.Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
